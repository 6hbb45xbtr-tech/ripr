async function rip(){
  const url = document.getElementById('urlInput').value;
  const toast = document.getElementById('toast');
  toast.innerText = 'Ripping...';
  try {
    const res = await fetch('/rip', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({url})
    });
    const data = await res.json();
    toast.innerText = data.message;
  } catch(e){
    toast.innerText = 'Error: ' + e;
  }
}