from fastapi import FastAPI
from pydantic import BaseModel
import subprocess, os

app = FastAPI()

class RipRequest(BaseModel):
    url: str

@app.post("/rip")
def rip(req: RipRequest):
    url = req.url
    os.makedirs("crates", exist_ok=True)
    try:
        # yt-dlp with ffmpeg
        cmd = ["yt-dlp", "-x", "--audio-format", "mp3", "-o", "crates/%(title)s.%(ext)s", url]
        subprocess.run(cmd, check=True)
        return {"message": f"Ripped: {url}"}
    except Exception as e:
        return {"message": f"Error: {str(e)}"}

@app.get("/recent")
def recent():
    if not os.path.exists("crates"):
        return {"recent": []}
    files = sorted(os.listdir("crates"), key=lambda x: os.path.getmtime(os.path.join("crates", x)), reverse=True)
    return {"recent": files[:5]}